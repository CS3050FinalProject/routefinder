"""
No need to register models for rest framework.
"""
#from django.contrib import admin

# Register your models here.
