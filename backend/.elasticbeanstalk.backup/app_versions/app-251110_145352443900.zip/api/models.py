#from django.db import models

"""
No models
"""
# Create your models here.
