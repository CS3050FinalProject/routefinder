"""
No need to register models for now.
"""
#from django.contrib import admin

# Register your models here.
